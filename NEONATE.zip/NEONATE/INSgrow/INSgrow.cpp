/*
 *	name:insgrow 
 *  author:shencong
 */
#include <ctype.h>                  
#include <string.h>
#include <stdio.h>
#include <iostream.h>
#include <stdlib.h>
#include <conio.h>
#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afx.h>

#define N 131075                     

struct gapnit
{
	char start, end;                  
	int min, max;                     
};
char p[200] = "a[0,1]a[0,1]g[0,1]a[0,1]a";

gapnit gap[N];                        //pattern p[i]
int gap_len = 0;                      //the length of pattern
int maxp_c = -1;                      

int nonolpcount = 0;
int zerosupport_count = 0;
//int support_count[30] = {0};

//int p_support[1000][1000] = {0};                  
long (*p_support)[170000] = new long[200][170000];

void dealrange(char *p, int len)     
{
	gap[gap_len].start = p[0];
	gap[gap_len].end = p[len];
	if (len == 1)
	{
		gap[gap_len].max = gap[gap_len].min = 0;
	}
	else
	{
		int value = 0;
		int i;
		int flag = 0;
		for (i = 2; p[i] != ','; i++)               
			if (p[i] == '-')                        
				flag = 1;
			else
				value = value * 10 + p[i] - 48;     
			if (flag == 0)
				gap[gap_len].min = value;
			else
				gap[gap_len].min = -value;              
			value = 0;
			flag = 0;
			//
			for (int j= i + 1; p[j] != ']'; j++)    
				if (p[j] == '-') 
					flag = 1;
				else
					value = value * 10 + p[j] - 48;
				if (flag == 0)
					gap[gap_len].max = value;       
				else
					gap[gap_len].max = -value;
	}
	if (gap[gap_len].max - gap[gap_len].min + 1 > maxp_c)
		maxp_c = gap[gap_len].max - gap[gap_len].min + 1;
	gap_len++;
	cout << gap_len << "ok" << endl;
}

void convert_p_to_ruler(char *p)     
{
	char st, en;
	int l, r;
	int len = strlen(p);             
	st = p[0];
	en = p[len - 1];
	if (isalpha(st) && isalpha(en))
	{
		l = 0;
		for (int i = 1; i < len; i++)
		{
			if (isalpha(p[i]))       //letter (A-Z or a-z)
			{
				r = i;
				dealrange(p + l,r - l);
				l = i;
			}
		}
	}
	else
		printf("irregular pattern");
}

void disp_pattern()                        
{
	for (int i = 0; i < gap_len; i++)
	{
		cout << gap[i].start << '\t' << gap[i].min << '\t' << gap[i].max << '\t' << gap[i].end << '\n';
	}
}

int zerosupport_num(char *s)
{
	long des_len = strlen(s);                       
	long count1 = 0;
    for(long m = 0; m < 200; m++)
		for(long n = 0; n < 170000; n++)
		{
			p_support[m][n] = -1;
			count1++;
		}

	for(long i = 0; i < des_len; i++)
	{
		if(s[i] == gap[0].start)
		{
			
			p_support[0][zerosupport_count] = i;
			zerosupport_count++;
		}
	}
	return zerosupport_count;
}


int insgrow_algrithm(char *s, int minlen, int maxlen)   
{
	//nonolp = new row[gap_len + 1];
	//create_nonolpnettree(maxlen);                 
	long des_len = strlen(s);                       
	nonolpcount = 0;
    //support_count[0] = zerosupport_count;
	long j = 0;
	for(long h = 0; h < gap_len; h++)    
	{
		for(long i = 0; i < zerosupport_count; i++)
		{   
			if(p_support[h][i] >= des_len - 1) 
			{
				break;
			}
			else if(p_support[h][i] == -1)    
			{
				continue;
			}
			else
			{
				for(j = p_support[h][i] + 1; j < des_len; j++)          
				{
					if(h != gap_len - 1)
					{
						if(j - p_support[h][i] - 1 > gap[h].max || 
							j - p_support[h][i] - 1 < gap[h].min || 
							(j - p_support[0][i] + 1) > maxlen 
							)
						{
							if((j - p_support[0][i] + 1) > maxlen)
								break;
							else
								continue;
						}
						else
						{
							if(s[j] == gap[h].end)		
								
							{
								if(i == 0)   
								{
									p_support[h + 1][i] = j;  
									//support_count[h + 1]++;    
									break;
								}
								else 
								{
									for(long m = i - 1; m >= 0 ; m--)
									{
										if(p_support[h + 1][m] == j)
											break;
										}
										else if(m == 0)
										{
											p_support[h + 1][i] = j;
											//support_count[h + 1]++
										}
									}
									break;
								}
							}
						}
					}
					else
					{
						if(j - p_support[h][i] - 1 > gap[h].max || 
							j - p_support[h][i] - 1 < gap[h].min || 
							(j - p_support[0][i] + 1) < minlen || 
							(j - p_support[0][i] + 1) > maxlen 
							)
						{
							continue;
						}
						else
						{
							if(s[j] == gap[h].end)	
							{
								if(i == 0)
								{
									p_support[h + 1][i] = j;
									//support_count[h + 1]++;
									break;
								}
								else 
								{
									for(long m = i - 1; m >= 0 ; m--)
									{
										if(p_support[h + 1][m] == j)
										{
											break;
										}
										else if(m == 0)
										{
											p_support[h + 1][i] = j;
											//support_count[h + 1]++;
										}
									}
									break;
								}
							}
						}
					}
				}
			}	
		}
	}
    nonolpcount = zerosupport_count;

	return nonolpcount;               
	
}//insgrow_algrithm

char* readFile(char *s)
{
	int k = 0;
    FILE *fp;
    if((fp = fopen("F:\\c++work\\Pattern-Matching-master\\NETLAP-Best\\INSgrow\\dataset\\SDB6.txt", "rt")) == NULL)
    {
		cout << "Cannot open file strike any key exit!";
		getch();
		exit(1);
    }
    char ch = fgetc(fp);
    while(ch!=EOF)
    {
		s[k] = ch;
		ch = fgetc(fp);
		k++;
	}
    fclose(fp);
	return s;
}

char* put_p(char* px, int xx)
{
	int put_i = 0;
	int p_len = strlen(px);

	for(put_i = 0; put_i < p_len; put_i++)
	{
		p[put_i] = px[put_i];
	}
	
	return px;
}

void main()
{
	//char fpn[]="AB131892.txt";
	//char s[150000] = "atcgatataggctatatattaga";                          
	//char s[150000] = "atcgatataggctatatcattaga";
	//char s[150000] = "atcgatataggctatatcattaataaatcggagtattatatcattaaaaaaccattagaatcgatataggctatatcattaga";
	//char s[170000] = "atcgatataggctatatcattaataaatcggagt";
	//char s[150000] = "atataa";
    //char p[100] = "a[0,2]t[0,2]g[0,2]a[0,2]g[0,2]a[0,2]c[0,2]t[0,2]g";
	
	//char p[200] = "a[0,2]t[0,2]g[0,5]a[0,2]g";
    
    //ģʽ��
	char p1[200] = "g[1,15]t[1,15]a[1,15]a[1,15]t[1,15]a";
    char p2[200] = "m[3,15]g[3,39]e[3,35]f";
	char p3[200] = "a[0,5]t[0,7]c[0,9]g[0,11]g";
    char p4[200] = "a[0,10]a[0,10]l[0,10]a";
	char p5[200] = "c[0,15]t[0,15]e[0,15]a[0,15]a";
	char p6[200] = "t[0,10]v[0,10]g";
	char p7[200] = "t[0,10]g[0,10]y";
	char p8[200] = "t[0,12]g[0,12]y";
	char p9[200] = "a[0,12]t[0,12]g";
    //

	char s[N];
	readFile(s);
	
	long minlen, maxlen;

	cout << "Choose pattern Number��" << endl;
	int xx = 0;
	cin >> xx;
    switch(xx) {
    case 1:
		minlen = 11;
		maxlen = 76;
		put_p(p1, 1);
		break;
    case 2:
		minlen = 13;
		maxlen = 40;
		put_p(p2, 2);
		break;
	case 3:
		minlen = 6;
		maxlen = 40;
		put_p(p3, 3);
		break;
    case 4:
		minlen = 6;
		maxlen = 32;
		put_p(p4, 4);
		break;
	case 5:
		minlen = 6;
		maxlen = 40;
		put_p(p5, 5);
		break;
    case 6:
		minlen = 6;
		maxlen = 30;
		put_p(p6, 6);
		break;
	case 7:
		minlen = 6;
		maxlen = 40;
		put_p(p7, 7);
		break;
    case 8:
		minlen = 6;
		maxlen = 29;
		put_p(p8, 8);
		break;
    case 9:
		minlen = 6;
		maxlen = 30;
		put_p(p9, 9);
		break;
    }
	
	convert_p_to_ruler(p);
	disp_pattern();
    cout << "Pattern" << endl;
	int nonolp_num = 0;
    cout << "ceshigap_len:" << gap_len << endl;
    
	long keyline_current;
	DWORD dwBeginTime = GetTickCount();
	for(int m=0;m<50;m++){
		long znum = zerosupport_num(s);
		cout << "zerosupport_num:" << znum << endl;
		long temp_count = 0;
	/*
		for(long j = 0; j < znum; j++)
		{
			cout << p_support[0][j] << " ";
			temp_count++;
			if(temp_count == 5)
			{
				cout << endl;
				temp_count = 0;
			}
		}
		cout << endl;
		*/
		cout << "Handling, wait��" << endl;

		int keyline = insgrow_algrithm(s, minlen, maxlen);

		cout << "landmark��" << endl;
		long x = 0, y = 0;
		keyline_current = keyline;   
		for(x = 0; x < keyline; x++)
		{
			for(y = 0; y <= gap_len; y++)
			{
				if(p_support[y][x] == -1)
				{
					keyline_current--;
					break;
				}
				else if(y == gap_len)
				{
					cout << "<";
					for(y = 0; y <= gap_len; y++)
					{
						{
							cout << p_support[y][x];
							if(y != gap_len)
							{
								cout << ", ";
							}
						}	
					}
					cout << ">" << endl;
				}
			}
		}
	}
	DWORD dwEndTime = GetTickCount();
	cout << "Time cost:" << dwEndTime - dwBeginTime << "ms" << endl;
	cout << "Occurrence number:" << keyline_current << endl;
	cout << endl << "End" << endl;
}