//NETLAP-LENGTH_parent child  �Կ��Է��ʵĺ��ӽ��������Ƿ�Ϊ��ʹ�ý��
#include <iostream.h>
#include <string.h>
#include <afxwin.h>
#include <vector>
using namespace std;
struct node
{
	int name;
	int min_root,max_root;
	int minLeaf,maxLeaf;
	vector <int> parent;
	vector <int> children;
	//int *parent,pn;
	//int *children,pc;
	bool used;
	bool toroot;//�ִ�����
	//bool toleave;//�ִ���Ҷ
};
#define N 200000
#define M 1000
char S[N];
char p[M]="0";
struct sub_ptn_struct
{
	char start,end;		//
	int min,max;		//
};
struct occurrence
{
	vector <int > position;
};
vector <occurrence> store;
sub_ptn_struct sub_ptn[M];  //pattern p[i]
int ptn_len=0;  //the length of pattern
int seq_len=0;
int maxgap=-1;

void createnettree_length(vector <node> *nettree)
{
	for (int i=0;i<ptn_len+1;i++)
		nettree[i].resize (0);//�������ʼ��
	int *start;
	start=new int[ptn_len+1];
	for (i=0;i<ptn_len+1;i++)
		start[i]=0;
	for (i=0;i<strlen(S);i++)
	{
		//��ÿ���ַ���һ���
		//�Խ����г�ʼ����
		//if (i==382)
		//	int tmp=5;
		node anode;
		anode.name =i;
		anode.parent.resize (0);
		anode.children .resize (0);
		anode.used =false;//û��ʹ��Ϊ�٣�ʹ��Ϊ��
		if (sub_ptn[0].start ==S[i])
		{
				//��������ֱ�Ӵ洢�ý��
			int len=nettree[0].size ();
			nettree[0].resize (len+1);
			anode.toroot =true;
			anode.min_root =anode.max_root =anode.name ;
			nettree[0][len]=anode;			
		}
		for (int j=0;j<ptn_len;j++)
		{
			if (sub_ptn[j].end==S[i])
			{
				//��һ������˫��
				int prev_len=nettree[j].size ();
				if (prev_len==0)
				{
					//˵�����޽�㣬�����˳�
					break;
				}
				//�������  ������
				for (int k=start[j];k<prev_len;k++)
				{
					int name=nettree[j][k].name;
					if (i-nettree[j][k].name -1>sub_ptn[j].max )
					{
						//��������Ͻ죬�α����
						start[j]++;
					}
				}
				//�жϼ�϶Լ��
				if (i-nettree[j][prev_len-1].name -1>sub_ptn[j].max)
				{
					//����������϶Լ��
					continue;
				}
				if (i-nettree[j][start[j]].name -1<sub_ptn[j].min)
				{
					continue;
				}
	
				int len=nettree[j+1].size ();
				nettree[j+1].resize (len+1);
				anode.min_root =nettree[j][start[j]].min_root ;
				anode.max_root =nettree[j][start[j]].max_root ;
				anode.toroot =true;
				nettree[j+1][len]=anode;
				for (k=start[j];k<prev_len;k++)
				{
					/*int name=nettree[j][k].name;
					if (i-nettree[j][k].name -1>sub_ptn[j].max )
					{
						//��������Ͻ죬�α����
						start[j]++;
						continue;
					}*/
					if (i-nettree[j][k].name -1<sub_ptn[j].min )
					{
						//��������½磬�˳�
						break;
					}
					//�ڼ�϶Լ��֮��
					//�������ӹ�ϵ
					int nc=nettree[j][k].children .size ();
					nettree[j][k].children.resize (nc+1);
					nettree[j][k].children [nc]=len;//�洢λ��
					int np=nettree[j+1][len].parent .size ();
					nettree[j+1][len].parent.resize (np+1);
					nettree[j+1][len].parent [np]=k;
					if (nettree[j+1][len].min_root >nettree[j][k].min_root )//�������϶�������� 
					{
						nettree[j+1][len].min_root =nettree[j][k].min_root;
					}
					if (nettree[j+1][len].max_root  <nettree[j][k].max_root )//�������϶��������
					{
						nettree[j+1][len].max_root  =nettree[j][k].max_root;
					}
				}

			}
		}
	}
	delete []start;
}
void displaynettree(vector <node> *nettree)
{
	for (int i=0;i<ptn_len+1;i++)
	{
		cout <<i<<":";
		for (int j=0;j<nettree[i].size ();j++)
			if (nettree[i][j].used ==false)
				cout <<nettree[i][j].name <<"\t";
		cout <<endl;
	}
}

void updatenettree(vector <node> *nettree,int *nodenumber)  //�޼����ܵ���Ҷ���Ľڵ�
{
	nodenumber[ptn_len]=nettree[ptn_len].size (); //Ҷ�ӽ���Ľ���ʼһ������
	for (int i=ptn_len-1;i>=0;i--)
	{
		nodenumber[i]=0;
		for(int j=nettree[i].size ()-1;j>=0;j--)
		{
			bool flag=true;
			int size=nettree[i][j].children.size ();
			for (int k=0;k<size;k++)
			{
				int child=nettree[i][j].children[k];
				if (nettree[i+1][child].used ==false)
				{
					flag=false;					
					nodenumber[i]++; //������¼ÿ����ý����
					break;
				}
			}
			//���ڲ��ִܵ�Ҷ�ӽ��Ľ�㣬��ʶΪ���ã�
			nettree[i][j].used =flag;
		}
	}
}
#include<stack>
struct storenode
{
	int position;
	int level;
};
void updatenettree_length_pc(vector <node> *nettree,occurrence &occin)
{
	//���㷨�����ƣ�����ȫ�����������������з�ʽ����Ӱ��Ľڵ��������
	//���и��׺��ӵĶ�����
	for (int level=0;level<ptn_len;level++)
	{
		int position=occin.position [level];		
		for (;position>=0;position--)
		{
			//��ǰ�ҵ�һ��û��ʹ�õĽ�����
			if (nettree[level][position].used ==false)
				break;
			//���Ӹ���
			int len=nettree[level][position].children .size ();
			//��ǰ���
			//int name=nettree[level][position].name ;
			for (int i=len-1;i>=0;i--)
			{
				//ÿ������
				int child=nettree[level][position].children [i];
				int ps=nettree[level+1][child].parent .size ();
				//int cn=nettree[level+1][child].name ;
				//�Ѿ��������߲��ɵִ�Ҷ��
				if (nettree[level+1][child].used ==true)
					continue;
				if (ps==1)//��һ��˫�ף�
				{
					//��һ��˫�׾�Ӧ�����������Ӳ�������
					//if (nettree[level+1][child].used ==false)
					//{
						nettree[level+1][child].used =true;
						nettree[level+1][child].toroot =false;
					//}
				}
				else
				{
					//���˫��
					for (int kk=ps-1;kk>=0;kk--)
					{
						int parent=nettree[level+1][child].parent [kk];
						int pn=nettree[level][parent].name ;
						if(nettree[level][parent].used ==false)
							break;
					}
					if (kk==-1)
					{
						nettree[level+1][child].used =true;
						nettree[level+1][child].toroot =false;
					}
				}	
			}
		}
	}	
}
int minvaleposition(int *nodenumber)
{
	int p=ptn_len;
	for (int i=p-1;i>=0;i--)
	{
		if (nodenumber[i]<=nodenumber[p])
			p=i;
	}
	return p;
}
void displayocc(occurrence &occ)
{
	//cout <<"An occurrence is:";
	cout <<"<";
	for (int i=0;i<ptn_len;i++)
		cout <<occ.position [i]<<",\t";
	cout <<occ.position [i];
	cout <<">"<<endl;
}
void displaychild(vector <node> *nettree)
{
	cout <<"--------child----------------\n";
	for (int i=0;i<ptn_len+1;i++)
	{
		cout <<i<<":";
		for (int j=0;j<nettree[i].size ();j++)
		{
			//if (nettree[i][j].LPN >0)
			{
				//�Բ��ִܵ���Ҷ��Ľ�㲻����ʾ
				cout <<nettree[i][j].children .size ()  <<"\t";
			}
		}
		cout <<endl;
	}
}

int findstartlevel(int start,int end,int *nodenumber){
	int nodecount=0;
	int flag=0;
	nodecount = nodenumber[start];
	//Ѱ�ҽڵ�����С�Ĳ���
	for(int level=start+1;level<=end;level++){
		if(nodecount>=nodenumber[level]){	
			nodecount=nodenumber[level];
			flag = level;
		}
	}
	return flag;
}

void countnumber(vector <node> *nettree,int flag,int minlen,int maxlen,int start,int end){
	for (int position=nettree[flag].size()-1;position>=0;position--){
		if(nettree[flag][position].used==true){
			continue;
		}
		if (nettree[flag][position].toroot ==false)
		{
			//Ϊ�ٱ�ʾ���ִܵ����
			continue;
		}
		int leaf=nettree[flag][position].name;
		vector <int> wz;
		wz.resize(ptn_len+1);
			
		int a=nettree[flag][position].minLeaf-nettree[flag][position].max_root+1;
		int b=nettree[flag][position].maxLeaf-nettree[flag][position].min_root+1;
		if (!( (minlen<=a&&a<=maxlen)||(minlen<=b&&b<=maxlen)))
		{
			nettree[flag][position].used =true;
			nettree[flag][position].toroot =false;
			//�����㳤��Լ��
			continue;
		}
		//��������
		occurrence occ;
		occurrence occin;//�������е�λ�ã�
		occ.position .resize (ptn_len+1);
		occin.position .resize (ptn_len+1);
		occin.position [flag]=position;
		occ.position [flag]=nettree[flag][position].name ;
		nettree[flag][position].used =true;
		nettree[flag][position].toroot =false;
		//���ϱ���
		for (int u=flag-1;u>=start;u--){
			//���ݺ���������˫��
			int child=occin.position [u+1];//�����������е�λ��
			int ps=nettree[u+1][child].parent.size ();//��ǰ����˫����
			for (int t=ps-1;t>=0;t--)
			{
				int parent=nettree[u+1][child].parent[t];//����˫�׵�λ��
				int a2=nettree[u][parent].minLeaf-nettree[u][parent].max_root+1;
				int b2=nettree[u][parent].maxLeaf-nettree[u][parent].min_root+1;
				//int val=nettree[j][parent].name;
				//int st=nettree[j][parent].used;
				if (nettree[u][parent].used ==false&&
					 ((a2<=maxlen&&a2>=minlen)||(b2>=minlen&&b2<=maxlen)))
				{
					occin.position[u]=parent;			
					int value=nettree[u][parent].name;
					occ.position [u]=value ;
					nettree[u][parent].used=true;
					nettree[u][parent].toroot =false;
					break;
				}
			}
			if (t==-1)
			{
				//�����г���Լ����Ե�ʲ�������ȫ�������ɲ������ֵ�����
				//�ָ�����
				for (int kk=flag-1;kk>u;kk--)
				{
					int pos=occin.position [kk];
					nettree[kk][pos].used=false;
					nettree[kk][pos].toroot =true;
				}
				break;
			}
		}
		if(u==-1)  //������ϱ����ɹ��������±���
		{
			for (int d=flag+1;d<=end;d++)
			{
				int child = occin.position[d-1];
				int ps = nettree[d-1][child].children.size();
				for(int p=ps-1;p>=0;p--)
				{
					int children = nettree[d-1][child].children[p];
					int a3=nettree[d][children].minLeaf-nettree[d][children].max_root+1;
					int b3=nettree[d][children].maxLeaf-nettree[d][children].min_root+1;
					if (nettree[d][children].used ==false&&
						((a3<=maxlen&&a3>=minlen)||(b3>=minlen&&b3<=maxlen)))
					{
						occin.position[d] = children;
						int value = nettree[d][children].name;
						occ.position[d] = value;
						nettree[d][children].used=true;
						nettree[d][children].toroot=false;
						wz[d]=p;
						break;
					}
				}
				if(p==-1)
				{
					for(int m=d-1;m>flag;m--){
						if(wz[m]!=0){
							d=m-1;
							break;
						}
					}
					if(m==flag){
						for (int pp=flag-1;pp>=0;pp--)
						{
							int pos=occin.position[pp];
							nettree[pp][pos].used=false;
							nettree[pp][pos].toroot=true;
						}
						break;
					}
				}
			}
			if (d==ptn_len+1){
				int len = store.size();
				store.resize (len+1);
				store[len]=occ;
				updatenettree_length_pc(nettree,occin);
				//displaynettree(nettree);
			}
		}
		else
			break;
	}
}
//version 1  ������Ҷ�Ӳ������
void nonoverlength(int minlen,int maxlen)
{
	vector <node> *nettree;
	nettree=new vector <node> [ptn_len+1];
	int *nodenumber;
	nodenumber=new int [ptn_len+1];
	createnettree_length(nettree);
	//displaynettree(nettree);
	updatenettree(nettree,nodenumber);
	//displaynettree(nettree);
	//displaychild(nettree);
	//����ÿ������minLeaf��maxLeaf����updatenettree�����������Ϊ�˷�ֹ�еĽ���޷�����Ҷ�ӽ��
	for(int j=0;j<nettree[ptn_len].size();j++){
		nettree[ptn_len][j].minLeaf=nettree[ptn_len][j].name;
		nettree[ptn_len][j].maxLeaf=nettree[ptn_len][j].name;
	}
	for(j=ptn_len-1;j>=0;j--){
		for(int i=0;i<nettree[j].size();i++){
			if(nettree[j][i].used==true)
				continue;
			int size=nettree[j][i].children.size();
			if(size==0)
				continue;
			int min=9999999;
			int max=0;
			for(int k=0;k<size;k++){
				int c=nettree[j][i].children[k];
				if(nettree[j+1][c].used==false){
					int a=nettree[j+1][c].name;
					if(min>nettree[j+1][c].minLeaf)
						min=nettree[j+1][c].minLeaf;
					if(max<nettree[j+1][c].maxLeaf)
						max=nettree[j+1][c].maxLeaf;
				}
			}
			nettree[j][i].minLeaf=min;
			nettree[j][i].maxLeaf=max;
			//cout<<min<<"\t";
			//cout<<max<<"\t";
		}
		//cout<<endl;
	}

	store.resize (0);

	int flag = findstartlevel(0,ptn_len,nodenumber);
	countnumber(nettree,flag,minlen,maxlen,0,ptn_len);
}

void dealrange(char *p,int len)      
//put sub-pattern "a[1,3]b" into sub_ptn and sub_ptn.start=a��sub_ptn.end=b, sub_ptn.min=1��sub_ptn.max=3
{
	sub_ptn[ptn_len].start =p[0];
	sub_ptn[ptn_len].end =p[len];
	if (len==1)
	{
		sub_ptn[ptn_len].max =sub_ptn[ptn_len].min=0;
	}
	else
	{
		int value=0;
		int i;
		for ( i=2;p[i]!=',';i++)
			value=value*10+p[i]-48;
		sub_ptn[ptn_len].min=value;		
		value=0;
		for (int j=i+1;p[j]!=']';j++)
			value=value*10+p[j]-48;
		sub_ptn[ptn_len].max=value;
	}
	if (sub_ptn[ptn_len].max-sub_ptn[ptn_len].min+1>maxgap)
		maxgap=sub_ptn[ptn_len].max-sub_ptn[ptn_len].min+1;
	ptn_len++;  //ptn_len�ĳ��ȱ�������patternС1
}

void convert_p_to_ruler(char *p)     //transform p into sub_ptn
{
	char st,en;
	int l,r ;
	int len=strlen(p);
	st=p[0];
	en=p[len-1];
	if (isalpha(st) && isalpha(en))
	{
		l=0;
		for (int i=1;i<len;i++)
		{
			if (isalpha(p[i]))
			{
				r=i;
				dealrange(p+l,r-l);  //p+l��Ϊ�˽�ָ��������һ����ĸ���Ŀ�ͷ char p[M]="a[0,1]g[0,1]a[0,2]a";
				l=i;
			}
		}
	}
	else
	{
		cout<<"irregular pattern.\n";
		exit(-1);
	}
}
void disp_pattern()         //display the array sub_ptn
{
	for (int i=0;i<ptn_len;i++)
	{
		//printf("%c\t%d\t%d\t%c\n",sub_ptn[i].start ,sub_ptn[i].min , sub_ptn[i].max ,sub_ptn[i].end );
		cout<<sub_ptn[i].start<<"\t"<<sub_ptn[i].min<<"\t"
			<<sub_ptn[i].max<<"\t"<<sub_ptn[i].end<<endl;
	}
	//cout<<ptn_len<<endl;
}
void Inputstr(char *fn,char *str)
{
	FILE* fp=fopen(fn,"r+");
	if (NULL==fp)
	{
		cout<<"Cannot find the file.\n";
		return;
	}
	fseek(fp,0,SEEK_END); 
	int len =ftell(fp);  //ftell���ص��ǵ�ǰ�ڵ�λ��
	fseek(fp,0,0); 
	fscanf(fp, "%s",str);
}
char* put_p(char* px, int xx)
{
	int put_i = 0;
	int p_len = strlen(px);
	
	for(put_i = 0; put_i < p_len; put_i++)
	{
		p[put_i] = px[put_i];
	}
	
	return px;
}
void main()
{
	//char p[M]="a[0,1]g[0,1]a[0,2]a";
	//char p[M]="a[0,3]t[0,3]a[0,3]t[0,3]a[0,3]t[0,3]a[0,3]t[0,3]a[0,3]t[0,3]a";
	
	//ģʽ��
	//char p1[200] = "a[0,3]t[0,3]a[0,3]t[0,3]a[0,3]t[0,3]a[0,3]t[0,3]a[0,3]t[0,3]a";
    //char p2[200] = "g[1,5]t[0,6]a[2,7]g[3,9]t[2,5]a[4,9]g[1,8]t[2,9]a";
	//char p3[200] = "g[1,9]t[1,9]a[1,9]g[1,9]t[1,9]a[1,9]g[1,9]t[1,9]a[1,9]g[1,9]t";
    //char p4[200] = "g[1,5]t[0,6]a[2,7]g[3,9]t[2,5]a[4,9]g[1,8]t[2,9]a[1,9]g[1,9]t";
	//char p5[200] = "a[0,10]a[0,10]t[0,10]c[0,10]g[0,10]g";
	//char p6[200] = "a[0,5]t[0,7]c[0,9]g[0,11]g";
	//char p7[200] = "a[0,5]t[0,7]c[0,6]g[0,8]t[0,7]c[0,9]g";
	//char p8[200] = "a[5,6]c[4,7]g[3,8]t[2,8]a[1,7]c[0,9]g";
	//char p9[200] = "c[0,5]t[0,5]g[0,5]a[0,5]a";
	char p1[200] = "g[1,15]t[1,15]a[1,15]a[1,15]t[1,15]a";
    char p2[200] = "m[3,15]g[3,39]e[3,35]f";
	char p3[200] = "a[0,5]t[0,7]c[0,9]g[0,11]g";
    char p4[200] = "a[0,10]a[0,10]l[0,10]a";
	char p5[200] = "c[0,15]t[0,15]e[0,15]a[0,15]a";
	char p6[200] = "t[0,10]v[0,10]g";
	char p7[200] = "t[0,10]g[0,10]y";
	char p8[200] = "t[0,12]g[0,12]y";
	char p9[200] = "a[0,12]t[0,12]g";
	//strcpy(S,"gaattcatcagccatggcagtttcataatattggattgatttaaagaagctacttcacacaggagactccttaaagattaggcgggaaggtgttcgtcttttcttactatggttgcaagctcttcagaataactgtagcaaagaacagctctggatgttttcatgcttaatccctggattttcagcaccacagtctgaacatggacctcgaactttagataatctcattaatcctccactcaacctttaagaaactcaagtcactatagaagaaatcactcctcttgt");//"aggtatagagaaaa");
	//strcpy(S,"gaattcatcagccatggcagtttcataatattggattgatttaaagaagctacttcacacaggagactccttaaagattaggcgggaaggtgttcgtcttttcttactatggttgcaagctcttcagaataactgtagcaaagaacagctctggatgttttcatgcttaatccctggattttcagcaccacagtctgaacatggacctcga");//"aggtatagagaaaa");
	//strcpy(S,"gaattcatcagccatggcagtttcataatattggattgatttaaagaagcta");
	//strcpy(S,"aggtatagagaaa");
	
	//char p[M]="a[0,4]t[0,6]g";
	//strcpy(S,"aatatggattatggg");
	//char p[M]="a[0,2]t[0,2]g";
	//strcpy(S,"aatgtgatgtg");
	//char p[M]="a[0,2]t[0,2]a";
	//strcpy(S,"atatatata");
	
	int minlen,maxlen;
	cout<<"Please input minlen and maxlen:";
	cout << "ѡ�ڼ���ģʽ��" << endl;
	int xx = 0;
	cin >> xx;
	//switch(xx) {
    //case 1:
	//	minlen = 11;
	//	maxlen = 76;
	//	put_p(p1, 1);
	//	break;
   // case 2:
	//	minlen = 13;
	//	maxlen = 40;
	//	put_p(p2, 2);
	//	break;
//	case 3:
	//	minlen = 6;
	//	maxlen = 40;
	//	put_p(p3, 3);
	//	break;
  //  case 4:
//		minlen = 6;
//		maxlen = 32;
//		put_p(p4, 4);
//		break;
//	case 5:
//		minlen = 6;
//		maxlen = 40;
//		put_p(p5, 5);
//		break;
//    case 6:
//		minlen = 6;
//		maxlen = 40;
//		put_p(p6, 6);
//		break;
//	case 7:
//		minlen = 6;
//		maxlen = 40;
//		put_p(p7, 7);
//		break;
 //   case 8:
//		minlen = 6;
//		maxlen = 30;
//		put_p(p8, 8);
//		break;

 //   }
    switch(xx) {
    case 1:
		minlen = 11;
		maxlen = 76;
		put_p(p1, 1);
		break;
    case 2:
		minlen = 13;
		maxlen = 40;
		put_p(p2, 2);
		break;
	case 3:
		minlen = 6;
		maxlen = 40;
		put_p(p3, 3);
		break;
    case 4:
		minlen = 6;
		maxlen = 32;
		put_p(p4, 4);
		break;
	case 5:
		minlen = 6;
		maxlen = 40;
		put_p(p5, 5);
		break;
    case 6:
		minlen = 6;
		maxlen = 30;
		put_p(p6, 6);
		break;
	case 7:
		minlen = 6;
		maxlen = 40;
		put_p(p7, 7);
		break;
    case 8:
		minlen = 6;
		maxlen = 29;
		put_p(p8, 8);
		break;
    case 9:
		minlen = 6;
		maxlen = 30;
		put_p(p9, 9);
		break;
    }
	//switch(xx) {
 //  case 1:
//		minlen = 11;
//		maxlen = 41;
//		put_p(p1, 1);
//		break;
 //   case 2:
//		minlen = 24;
//		maxlen = 65;
//		put_p(p2, 2);
//		break;
//	case 3:
//		minlen = 23;
//		maxlen = 110;
//		put_p(p3, 3);
//		break;
 //   case 4:
//		minlen = 27;
//		maxlen = 96;
//		put_p(p4, 4);
//		break;
//	case 5:
//		minlen = 6;
//		maxlen = 56;
//		put_p(p5, 5);
//		break;
//    case 6:
//		minlen = 5;
//		maxlen = 37;
//		put_p(p6, 6);
//		break;
//	case 7:
//		minlen = 7;
//		maxlen = 50;
//		put_p(p7, 7);
//		break;
//    case 8:
//		minlen = 22;
//		maxlen = 52;
//		put_p(p8, 8);
//		break;
  //  case 9:
	//	minlen = 5;
//		maxlen = 25;
//		put_p(p9, 9);
//		break;
 //   }
	convert_p_to_ruler(p);
	cout<<"The pattern can written as follows:\n";
	disp_pattern();		
	cout<<p<<endl;
	char fsn[]="dataset\\SDB6.txt";
	//Inputstr(fpn,p);
	Inputstr(fsn,S);
	//cout<<S<<endl;

	DWORD begintime=GetTickCount();
	for(int m=0;m<50;m++){
		nonoverlength(minlen,maxlen);
	}
	DWORD endtime=GetTickCount();
	int numcount = 0;
	for (int i=0;i<store.size ();i++)
	{
		displayocc(store[i]);
		numcount++;
	}
	cout << numcount << endl;
	cout <<"��ʱ"<<endtime-begintime<<"ms. \n";
	cout <<"����"<<store.size ()<<"������\n";

}